package main

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"html/template"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const (
	addr          = ":8000"
	adminUser     = "admin"
	adminPassword = "admin_@#$_0981234765"
	cookieName    = "ctf_session"
)

var flagValue = func() string {
	if v := os.Getenv("FLAG"); v != "" {
		return v
	}
	return "CHC{misc_chain_headers_hex_rot13_reverse1337}"
}()

var (
	hmacKey   []byte
	sessions  = map[string]time.Time{}
	tpl       *template.Template
	startedAt = time.Now()
)

func main() {
	hmacKey = mustRandBytes(32)

	var err error
	tpl, err = template.ParseGlob(filepath.Join("templates", "*.html"))
	if err != nil {
		log.Fatalf("parse templates: %v", err)
	}

	mux := http.NewServeMux()

	
	mux.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("static"))))
	mux.Handle("/assets/", http.StripPrefix("/assets/", http.FileServer(http.Dir("assets"))))
	mux.Handle("/hints/", http.StripPrefix("/hints/", http.FileServer(http.Dir("hints"))))

	
	mux.HandleFunc("/", handleIndex)
	mux.HandleFunc("/login", handleLogin)
	mux.HandleFunc("/logout", handleLogout)

	
	mux.HandleFunc("/robots.txt", handleRobots)
	mux.HandleFunc("/api/ping", handleAPIPing)
	mux.HandleFunc("/internal/door", handleDoor)
	mux.HandleFunc("/internal/k1", handleK1)
	mux.HandleFunc("/internal/k2", handleK2)

	
	mux.HandleFunc("/admin", requireAuth(handleAdmin))
	mux.HandleFunc("/flag", requireAuth(handleFlag))


	log.Printf("Server running on http://localhost%s", addr)
	if err := http.ListenAndServe(addr, withSecurityHeaders(mux)); err != nil {
		log.Fatal(err)
	}
}



func handleIndex(w http.ResponseWriter, r *http.Request) {
	
	w.Header().Set("X-Hint", "robots")

	render(w, "index.html", map[string]any{
		"LoggedIn": isLoggedIn(r),
		"Uptime":   time.Since(startedAt).Round(time.Second).String(),
	})
}

func handleLogin(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		u := r.URL.Query().Get("u")
		render(w, "login.html", map[string]any{
			"Error": "",
			"User":  u,
		})
	case http.MethodPost:
		if err := r.ParseForm(); err != nil {
			render(w, "login.html", map[string]any{"Error": "Ошибка формы", "User": ""})
			return
		}

		u := strings.TrimSpace(r.FormValue("username"))
		p := r.FormValue("password")

		if u != adminUser || p != adminPassword {
			render(w, "login.html", map[string]any{
				"Error": "Неверный логин или пароль",
				"User":  u,
			})
			return
		}

		token := randomToken(32)
		expires := time.Now().Add(2 * time.Hour)
		sessions[token] = expires

		http.SetCookie(w, &http.Cookie{
			Name:     cookieName,
			Value:    signToken(token),
			Path:     "/",
			HttpOnly: true,
			SameSite: http.SameSiteLaxMode,
			Expires:  expires,
		})

		http.Redirect(w, r, "/admin", http.StatusSeeOther)

	default:
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
	}
}

func handleLogout(w http.ResponseWriter, r *http.Request) {
	http.SetCookie(w, &http.Cookie{
		Name:     cookieName,
		Value:    "",
		Path:     "/",
		MaxAge:   -1,
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
	})
	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func handleAdmin(w http.ResponseWriter, r *http.Request) {
	render(w, "admin.html", map[string]any{"User": adminUser})
}

func handleFlag(w http.ResponseWriter, r *http.Request) {
	render(w, "flag.html", map[string]any{"Flag": flagValue})
}

func handleWriteup(w http.ResponseWriter, r *http.Request) {
	
	render(w, "writeup.html", map[string]any{
		"Flag": flagValue,
	})
}



func handleRobots(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	_, _ = w.Write([]byte(
		"User-agent: *\n" +
			"Disallow: /admin\n" +
			"Disallow: /flag\n" +
			"Disallow: /hints/\n" +
			"\n# CTF: sometimes Disallow contains the path you need.\n",
	))
}


func handleAPIPing(w http.ResponseWriter, r *http.Request) {
	path := "/internal/door"
	rot := rot13(path)
	hexed := hex.EncodeToString([]byte(rot))
	b64 := base64.RawStdEncoding.EncodeToString([]byte(hexed))

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("X-CTF", b64)
	_, _ = w.Write([]byte(`{"status":"ok","hint":"check response headers (X-CTF)"}`))
}


func handleDoor(w http.ResponseWriter, r *http.Request) {
	prefixB64 := base64.RawStdEncoding.EncodeToString([]byte("admin_@#$_"))
	render(w, "door.html", map[string]any{
		"PrefixB64": prefixB64,
	})
}


func handleK1(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	payload := base64.RawStdEncoding.EncodeToString([]byte("321890"))
	_, _ = w.Write([]byte("KEY1=" + payload + "\nHINT: base64 decode, then reverse digits\n"))
}


func handleK2(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	hexBytes := hex.EncodeToString([]byte("4765")) 
	_, _ = w.Write([]byte("KEY2_HEX_BYTES=" + hexBytes + "\nHINT: hex-decode bytes to ASCII\n"))
}



func requireAuth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if !isLoggedIn(r) {
			http.Redirect(w, r, "/login", http.StatusSeeOther)
			return
		}
		next(w, r)
	}
}

func isLoggedIn(r *http.Request) bool {
	c, err := r.Cookie(cookieName)
	if err != nil {
		return false
	}
	token, ok := verifySignedToken(c.Value)
	if !ok {
		return false
	}
	exp, ok := sessions[token]
	if !ok {
		return false
	}
	if time.Now().After(exp) {
		delete(sessions, token)
		return false
	}
	return true
}



func signToken(token string) string {
	sig := hmacSHA256([]byte(token), hmacKey)
	return token + "|" + base64.RawURLEncoding.EncodeToString(sig)
}

func verifySignedToken(value string) (string, bool) {
	parts := strings.Split(value, "|")
	if len(parts) != 2 {
		return "", false
	}
	token := parts[0]
	sigB64 := parts[1]

	sig, err := base64.RawURLEncoding.DecodeString(sigB64)
	if err != nil {
		return "", false
	}
	expected := hmacSHA256([]byte(token), hmacKey)
	if !hmac.Equal(sig, expected) {
		return "", false
	}
	return token, true
}

func hmacSHA256(data, key []byte) []byte {
	m := hmac.New(sha256.New, key)
	m.Write(data)
	return m.Sum(nil)
}



func randomToken(n int) string {
	b := mustRandBytes(n)
	return base64.RawURLEncoding.EncodeToString(b)
}

func mustRandBytes(n int) []byte {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		panic(err)
	}
	return b
}

func render(w http.ResponseWriter, name string, data any) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tpl.ExecuteTemplate(w, name, data); err != nil {
		http.Error(w, "Template error: "+err.Error(), http.StatusInternalServerError)
	}
}

func withSecurityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; style-src 'self';")
		w.Header().Set("Referrer-Policy", "no-referrer")
		next.ServeHTTP(w, r)
	})
}

func rot13(s string) string {
	var b strings.Builder
	b.Grow(len(s))
	for _, r := range s {
		switch {
		case r >= 'a' && r <= 'z':
			b.WriteRune('a' + (r-'a'+13)%26)
		case r >= 'A' && r <= 'Z':
			b.WriteRune('A' + (r-'A'+13)%26)
		default:
			b.WriteRune(r)
		}
	}
	return b.String()
}